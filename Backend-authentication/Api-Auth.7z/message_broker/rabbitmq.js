const amqp = require("amqplib");
const HttpError = require("../models/http-error");

module.exports = {
  send: async (message) => {
    try {
      const connection = await amqp.connect("amqp://localhost");
      const channel = await connection.createChannel();
      channel.assertQueue(process.env.QUEUE_NAME);
      channel.sendToQueue(process.env.QUEUE_NAME, Buffer.from(JSON.stringify(message)));
      console.log("Sended", message);
    } catch (error) {
      console.log("Error in /message_broker/rabbitmq send():::", error);
      throw new HttpError("SERVER_INTERNAL_ERROR", 500);
    }
  },
};
