const express = require("express");
const authsRoute = require("../routes/auths");
const swaggerJsDoc = require("swagger-jsdoc");
const swaggerUi = require("swagger-ui-express");
const { Worker } = require("worker_threads");
require("dotenv").config();

const swaggerOptions = {
  swaggerDefinition: {
    openapi: "3.0.0",
    components: {
      securitySchemes: {
        jwt: {
          type: "http",
          scheme: "bearer",
          in: "header",
          bearerFormat: "JWT",
        },
      },
    },
    security: [{ jwt: [] }],
    info: {
      title: "Auths API",
      description: "Auths information",
      contact: {
        name: "Phuong",
      },
      servers: ["http://localhost:3001"],
    },
  },
  apis: ["./routes/*.js"],
};
const swaggerDocs = swaggerJsDoc(swaggerOptions);

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocs));

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept,Authorization"
  );
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
  next();
});

app.use("/auths", authsRoute);

app.use((error, req, res, next) => {
  res.status(error.errorCode);
  res.json({ message: error.message });
});

app.listen(3001);

const signUpWorker = new Worker("./worker/signup.js");
