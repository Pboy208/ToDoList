const User = require("../models/user");
const amqp = require("amqplib/callback_api");

console.log("Worker started");

amqp.connect("amqp://localhost", (error, connection) => {
  try {
    if (error) {
      throw error;
    }
    connection.createChannel((channelError, channel) => {
      if (channelError) {
        throw channelError;
      }
      channel.assertQueue(process.env.QUEUE_NAME);
      channel.consume(process.env.QUEUE_NAME, async (message) => {
        if (message) {
          try {
            const signUpInfo = JSON.parse(userInfo);
            const user = new User(signUpInfo);
            const userId = await user.storeToDB();
            return channel.ack(message);
          } catch (messageError) {
            return console.log("message error in consumer worker:::", messageError);
          }
        }
      });
    });
  } catch (connectionError) {
    console.log("connection error in consumer worker:::", connectionError);
  }
});
