const User = require("../models/user");
const HttpError = require("../models/http-error");
const jwt = require("jsonwebtoken");
const loginInfoSchema = require("../schemas/loginInfo");
const userSchema = require("../schemas/user");
const singUpInfoSchema = require("../schemas/signUpInfo");
const messageBroker = require("../message_broker/rabbitmq");

const createToken = (payload) => {
  token = jwt.sign(payload, process.env.TOKEN_SECURITY_KEY, {
    expiresIn: process.env.TOKEN_EXPIRATION,
  });
  return token;
};

const getTokenFromReq = (req) => {
  return req.headers.authorization.split(" ")[1];
};

//user story1
exports.login = async (req, res, next) => {
  const validReq = loginInfoSchema(req.body);
  if (!validReq) {
    return next(new HttpError("USER_INVALID_INPUT", 400));
  }

  try {
    const user = new User({ username: req.body.username, password: req.body.password });

    const validUser = await user.login();
    if (!validUser) {
      return next(new HttpError("USER_INVALID_LOGININFO", 400));
    }

    const token = createToken({
      userId: user.id,
      fullname: user.fullname,
      username: user.username,
      address: user.address,
      email: user.email,
    });
    return res.status(200).send({ token: token });
  } catch (error) {
    next(error);
  }
};

//story2
exports.tokenReview = async (req, res, next) => {
  try {
    const token = getTokenFromReq(req);
    if (!token) {
      throw new Error();
    }
    jwt.verify(token, process.env.TOKEN_SECURITY_KEY);
    const decodedToken = jwt.decode(token);
    const newToken = createToken({
      userId: decodedToken.userId,
      fullname: decodedToken.fullname,
      username: decodedToken.username,
      address: decodedToken.address,
      email: decodedToken.email,
    });
    return res.status(200).send({ token: newToken });
  } catch (error) {
    next(new HttpError("TOKEN_INVALID", 401));
  }
};

//story3
exports.addAccount = async (req, res, next) => {
  const valid = userSchema(req.body);
  if (!valid) {
    return next(new HttpError("USER_INVALID_INPUT", 400));
  }

  try {
    const user = new User(req.body);

    const isExistedInput = await user.isExistedUsername();
    if (isExistedInput) {
      return next(new HttpError("USER_EXISTED_USERNAME", 409));
    }

    const userId = await user.storeToDB();
    return res.status(200).send({ message: "Successfully" });
  } catch (error) {
    next(error);
  }
};

//stort4
exports.changeAccoutnInfomation = async (req, res, next) => {
  const valid = userSchema(req.body);
  if (!valid) {
    return next(new HttpError("USER_INVALID_INPUT", 400));
  }

  try {
    const isFound = await User.isIdExisted(req.params.userId);
    if (!isFound) {
      return next(new HttpError("USER_NOTFOUND", 404));
    }

    const isOwner = req.params.userId === req.userData.userId;
    if (!isOwner) {
      return next(new HttpError("TOKEN_ACCESS_DENIED", 403));
    }

    const accountInfo = {
      id: req.params.userId,
      ...req.body,
    };
    const user = new User(accountInfo);

    await user.updateAccountInformation();
    return res.status(200).send({ message: "Successfully" });
  } catch (error) {
    next(error);
  }
};

//story5
exports.getAllAccounts = async (req, res, next) => {
  try {
    const accountList = await User.getAll();
    return res.status(200).send({ data: accountList });
  } catch (error) {
    next(error);
  }
};

//story6
exports.getAccountInfoById = async (req, res, next) => {
  try {
    const isFound = await User.isIdExisted(req.params.userId);
    if (!isFound) {
      return next(new HttpError("USER_NOTFOUND", 404));
    }

    const user = await User.getAccountInfoById(req.params.userId);
    return res.status(200).send({ data: user });
  } catch (error) {
    next(error);
  }
};

//story7
exports.signUp = async (req, res, next) => {
  try {
    const isValidInput = singUpInfoSchema(req.body);
    const isPWConfirmMatch = req.body.password === req.body.passwordConfirm;
    if (!isValidInput || !isPWConfirmMatch) {
      return next(new HttpError("USER_INVALID_INPUT", 400));
    }

    const user = new User(req.body);
    const isExistedInput = await user.isExistedUsername();
    if (isExistedInput) {
      return next(new HttpError("USER_EXISTED_USERNAME", 409));
    }

    await messageBroker.send(req.body);
    res.status(200).send({ message: "successfully" });
  } catch (error) {
    next(error);
  }
};
