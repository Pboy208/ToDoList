module.exports = {
  TASKS_PER_OFFSET: 10,
  TOKEN_SECURITY_KEY: "private_key_important",
};
