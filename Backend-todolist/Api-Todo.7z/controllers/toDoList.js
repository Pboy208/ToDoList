const taskSchema = require("../schemas/task");
const Task = require("../models/task");
const HttpError = require("../models/http-error");

// infinity scroll
exports.getListByOffset = async (req, res, next) => {
  try {
    console.log(req.userData.userId, req.params.offset);
    const toDoList = await Task.getByOffset(req.userData.userId, req.params.offset);
    console.log(toDoList);
    return res.status(200).send(toDoList);
  } catch (error) {
    next(error);
  }
};

//user story1
exports.getToDoList = async (req, res, next) => {
  try {
    const toDoList = await Task.getAll(req.userData.userId);
    return res.status(200).send(toDoList);
  } catch (error) {
    next(error);
  }
};

//user story2
exports.addTaskToList = async (req, res, next) => {
  const valid = taskSchema(req.body);
  if (!valid) {
    return next(new HttpError("TASK_INVALID_INPUT", 400));
  }
  try {
    const newTask = new Task(req.body);
    newTask.creatorId = req.userData.userId;

    const isDuplicatedName = await newTask.isExistedName();
    if (isDuplicatedName) {
      return next(new HttpError("TASK_EXISTED_NAME", 409));
    }

    const taskId = await newTask.storeToList();
    return res.status(200).send({ id: taskId });
  } catch (error) {
    next(error);
  }
};

//user story3
exports.changeTaskInList = async (req, res, next) => {
  const valid = taskSchema(req.body);
  if (!valid) {
    return next(new HttpError("TASK_INVALID_INPUT", 400));
  }

  try {
    const isFound = await Task.isIdExisted(req.params.taskId);
    if (!isFound) {
      return next(new HttpError("TASK_NOT_EXISTS", 404));
    }

    const taskInfo = {
      id: req.params.taskId,
      ...req.body,
    };
    const newTask = new Task(taskInfo);

    const isDuplicateName = await newTask.isExistedName();
    if (isDuplicateName) {
      return next(new HttpError("TASK_EXISTED_NAME", 409));
    }

    await newTask.updateToList();
    return res.status(200).send({});
  } catch (error) {
    next(error);
  }
};

//user story4
exports.deleteTaskFromList = async (req, res, next) => {
  try {
    const isFound = await Task.isIdExisted(req.params.taskId);
    if (!isFound) {
      return next(new HttpError("TASK_NOT_EXISTS", 404));
    }

    await Task.deleteFromList(req.params.taskId);
    return res.status(200).send({});
  } catch (error) {
    next(error);
  }
};
