const client = require("./es-wrapper.js");

module.exports = class User {
  static async isIdExisted(id) {
    try {
      await client.get({
        index: "account",
        id: id,
        type: "doc",
      });
      return true;
    } catch (error) {
      return false;
    }
  }
};
